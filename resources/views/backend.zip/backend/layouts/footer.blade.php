<footer id="footer" class="footer">
    {{-- <div class="copyright">
      &copy; {{ date('Y') }} Copyright <strong><span>Blog</span></strong>. All Rights Reserved
    </div> --}}
  
</footer><!-- End Footer -->

<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>